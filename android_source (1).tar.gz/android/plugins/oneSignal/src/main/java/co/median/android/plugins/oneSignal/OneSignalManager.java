package co.median.android.plugins.oneSignal;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;

import com.onesignal.OSDeviceState;
import com.onesignal.OneSignal;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import co.median.median_core.GoNativeActivity;
import co.median.median_core.LeanUtils;

public class OneSignalManager {

    public static final String TAG = OneSignalManager.class.getName();
    public static String NATIVE_CALLBACK = "median_onesignal_info";
    public static String NATIVE_CALLBACK_LEGACY = "gonative_onesignal_info";
    private OneSignalNotificationHandler notificationHandler;
    private String appId;
    private boolean isPageReady = false;

    public OneSignalManager() {
    }

    // Initial One Signal SDK
    public void setupOneSignal(Activity activity, String appId, boolean requiresUserPrivacyConsent) {
        this.appId = appId;
        OneSignal.initWithContext(activity);
        OneSignal.setAppId(appId);
        OneSignal.setRequiresUserPrivacyConsent(requiresUserPrivacyConsent);

        this.notificationHandler = new OneSignalNotificationHandler(activity);
        OneSignal.setNotificationOpenedHandler(notificationHandler);
        setupSubscriptionObserver(activity);
    }

    private void setupSubscriptionObserver(Activity activity) {
        OneSignal.addSubscriptionObserver(stateChanges -> {
            // Called when OneSignal subscription info is updated

            // This is to trigger a data changed event for the RegistrationManager
            if (activity instanceof GoNativeActivity) {
                ((GoNativeActivity) activity).onSubscriptionChanged();
            }

            // Resend info to native callback
            if (isPageReady) {
                sendOneSignalInfo(activity, NATIVE_CALLBACK);
            }
        });
    }

    public void showForegroundNotifications(boolean show) {
        OneSignal.setNotificationWillShowInForegroundHandler(event -> {
            if (show) event.complete(event.getNotification());
            else event.complete(null);
        });
    }

    public void promptForPushNotifications() {
        OneSignal.promptForPushNotifications();
    }

    public void promptForPushNotifications(Activity activity, String callback) {
        OneSignal.promptForPushNotifications(false, b -> {
            Log.d(TAG, "promptForPushNotifications: Register Notification Response: " + b);
            try {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("isSubscribed", b);
                PluginUtils.sendCallback(activity, callback, jsonObject);
            } catch (JSONException jsonException) {
                Log.e(TAG, "promptForPushNotifications: ", jsonException);
            }
        });
    }

    public void setInAppMessageClickHandler(Activity activity, String handler) {
        if (TextUtils.isEmpty(handler)) return;
        OneSignal.setInAppMessageClickHandler(action -> {
            Log.d(TAG, "In-app message clicked");

            HashMap<String, Object> map = new HashMap<>();
            map.put("clickName", action.getClickName());
            map.put("clickUrl", action.getClickUrl());
            map.put("firstClick", action.isFirstClick());
            map.put("closesMessage", action.doesCloseMessage());

            JSONObject jsonObject = new JSONObject(map);
            PluginUtils.sendCallback(activity, handler, jsonObject);
        });
    }

    public void promptLocation() {
        OneSignal.promptLocation();
    }

    public void provideUserConsent(boolean consent) {
        OneSignal.provideUserConsent(consent);
    }

    public void setExternalUserId(Activity activity, String externalId, String callback) {
        if (TextUtils.isEmpty(externalId)) return;
        Log.d(TAG, "setExternalUserId: setting id to: " + externalId);
        OneSignal.setExternalUserId(externalId, new OneSignal.OSExternalUserIdUpdateCompletionHandler() {
            @Override
            public void onSuccess(JSONObject jsonObject) {
                Log.d(TAG, "setExternalUserId: success");
                PluginUtils.sendSuccessCallback(activity, callback);
            }

            @Override
            public void onFailure(OneSignal.ExternalIdError externalIdError) {
                Log.d(TAG, "setExternalUserId: failed: " + externalIdError);
                PluginUtils.sendErrorCallback(activity, callback, externalIdError.toString());
            }
        });
    }

    public void removeExternalUserId(Activity activity, String callback) {
        Log.d(TAG, "removeExternalUserId: removing. . .");
        OneSignal.removeExternalUserId(new OneSignal.OSExternalUserIdUpdateCompletionHandler() {
            @Override
            public void onSuccess(JSONObject jsonObject) {
                Log.d(TAG, "removeExternalUserId: success");
                PluginUtils.sendSuccessCallback(activity, callback);
            }

            @Override
            public void onFailure(OneSignal.ExternalIdError externalIdError) {
                Log.d(TAG, "removeExternalUserId: onFailure: " + externalIdError);
                PluginUtils.sendErrorCallback(activity, callback, externalIdError.toString());
            }
        });
    }

    public void getTags(Activity activity, String callback) {
        if (TextUtils.isEmpty(callback)) return;
        try {
            OneSignal.getTags(tags -> {
                JSONObject results = new JSONObject();
                try {
                    results.put("success", true);
                    if (tags != null) {
                        results.put("tags", tags);
                    } else {
                        results.put("tags", new JSONObject());
                    }
                } catch (JSONException e) {
                    Log.e(TAG, "Error json encoding tags", e);
                }

                // run on main thread
                Handler mainHandler = new Handler(activity.getMainLooper());
                mainHandler.post(() -> PluginUtils.sendCallback(activity, callback, results));
            });
        } catch (Exception ex) {
            Log.e(TAG, "Error occurred", ex);
            PluginUtils.sendErrorCallback(activity, callback, ex.getMessage());
        }
    }

    public void setTags(JSONObject tags) {
        if (tags == null) return;
        OneSignal.sendTags(tags);
    }

    public void deleteTags(Activity activity, JSONArray tags, String callback) {
        if (tags != null) {
            for (int i = 0; i < tags.length(); i++) {
                String tag = tags.optString(i);
                if (!TextUtils.isEmpty(tag)) {
                    OneSignal.deleteTag(tag);
                }
            }
        } else {
            deleteAllTags();
        }
        PluginUtils.sendSuccessCallback(activity, callback);
    }

    public void deleteAllTags() {
        OneSignal.getTags(jsonObject -> {
            if (jsonObject == null) return;
            Iterator<String> keys = jsonObject.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                OneSignal.deleteTag(key);
            }
        });
    }

    public void addTrigger(String key, String value) {
        if (TextUtils.isEmpty(key) || TextUtils.isEmpty(value)) return;
        OneSignal.addTrigger(key, value);
    }

    public void addTriggers(Object triggers) {
        Map<String, Object> mapObject = LeanUtils.jsonToMap(triggers);
        OneSignal.addTriggers(mapObject);
    }

    public void removeTrigger(String key) {
        if (TextUtils.isEmpty(key)) return;
        OneSignal.removeTriggerForKey(key);
    }

    public void getTriggerValueForKey(Activity activity, String key) {
        if (TextUtils.isEmpty(key)) return;
        String value = (String) OneSignal.getTriggerValueForKey(key);
        HashMap<String, Object> map = new HashMap<>();
        map.put("key", key);
        map.put("value", value);
        PluginUtils.sendCallback(activity, "gonative_iam_trigger_value", new JSONObject(map));
    }

    public void startSubscriptionActivity(Context context) {
        Intent intent = new Intent(context, SubscriptionsActivity.class);
        context.startActivity(intent);
    }

    public void pauseInAppMessages(boolean pause) {
        OneSignal.pauseInAppMessages(pause);
    }

    public void sendOneSignalInfo(Activity activity, String callback) {
        Map<String, Object> installationInfo = getInstallationInfo();
        if (installationInfo == null || installationInfo.isEmpty()) return;

        try {
            Map<String, Object> toSend = new HashMap<>(installationInfo);

            if (activity instanceof GoNativeActivity) {
                toSend.putAll(((GoNativeActivity) activity).getDeviceInfo());
            }

            PluginUtils.sendCallback(activity, callback, new JSONObject(toSend));
            if (NATIVE_CALLBACK.equals(callback)) {
                // For apps that still uses gonative
                PluginUtils.sendCallback(activity, NATIVE_CALLBACK_LEGACY, new JSONObject(toSend));
            }
        } catch (Exception ex) {
            Log.e(TAG, "sendOneSignalInfo: ", ex);
        }
    }

    public Map<String, Object> getInstallationInfo() {
        Map<String, Object> installationInfo = new HashMap<>();

        try {
            OSDeviceState state = OneSignal.getDeviceState();
            boolean isSubscribed = false;
            if (state != null) {

                String userId = state.getUserId();
                String pushToken = state.getPushToken();
                isSubscribed = state.isSubscribed();

                if (!TextUtils.isEmpty(userId)) {
                    installationInfo.put("oneSignalUserId", userId);
                }

                if (!TextUtils.isEmpty(pushToken)) {
                    installationInfo.put("oneSignalPushToken", pushToken);

                    // registration id is old GCM name, but keep it for compatibility
                    installationInfo.put("oneSignalRegistrationId", pushToken);
                }

                installationInfo.put("oneSignalNotificationsEnabled", state.areNotificationsEnabled());
                installationInfo.put("oneSignalPushDisabled", state.isPushDisabled());
            }

            installationInfo.put("oneSignalSubscribed", isSubscribed);
            installationInfo.put("oneSignalRequiresUserPrivacyConsent", !OneSignal.userProvidedPrivacyConsent());
            return installationInfo;
        } catch (Exception ex) {
            Log.e(TAG, "Error setting up installation info map", ex);
        }
        return null;
    }

    public void setPageReady(boolean ready) {
        this.isPageReady = ready;
        if (notificationHandler != null) notificationHandler.setPageReady(ready);
    }

    public void clearAllNotifications() {
        OneSignal.clearOneSignalNotifications();
    }
}
