package co.median.android.plugins.oneSignal;

import android.app.Activity;
import android.net.Uri;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;

import co.median.median_core.AppConfig;
import co.median.median_core.BaseBridgeModule;
import co.median.median_core.GoNativeActivity;
import co.median.median_core.GoNativeContext;

public class OneSignalPlugin extends BaseBridgeModule {
    
    private static final String TAG = OneSignalPlugin.class.getName();
    private static OneSignalManager manager;

    @Override
    public void onApplicationCreate(GoNativeContext context) {
        super.onApplicationCreate(context);
        AppConfig appConfig = AppConfig.getInstance(context);

        if (appConfig.oneSignalEnabled) {
            manager = new OneSignalManager();
        }
    }
    
    @Override
    public <T extends Activity & GoNativeActivity> void onActivityCreate(T activity, boolean isRoot) {
        super.onActivityCreate(activity, isRoot);
        AppConfig appConfig = AppConfig.getInstance(activity);

        if (appConfig.oneSignalEnabled && manager != null) {
            // Initialize SDK
            manager.setupOneSignal(activity, appConfig.oneSignalAppId, appConfig.oneSignalRequiresUserPrivacyConsent);

            // Foreground notification behavior
            manager.showForegroundNotifications(appConfig.oneSignalShowForegroundNotifications);

            // Startup push prompt
            if (appConfig.oneSignalAutoRegister && appConfig.canEvokePushRequestOnce()) {
                manager.promptForPushNotifications();
            }
        }
    }
    
    @Override
    public <T extends Activity & GoNativeActivity> boolean shouldOverrideUrlLoading(T activity, Uri url, JSONObject params) {
        
        if ("onesignal".equals(url.getHost())) {

            if (manager == null) {
                Log.e(TAG, "shouldOverrideUrlLoading: OneSignal plugin disabled");
                return true;
            }

            if ("/tags/get".equals(url.getPath()) && params != null) {
                manager.getTags(activity, params.optString("callback"));
                return true;
            }
            
            if ("/tags/set".equals(url.getPath()) && params != null) {
                JSONObject tags = params.optJSONObject("tags");
                String callback = params.optString("callback");
                try {
                    if (tags == null) {
                        tags = new JSONObject(params.optString("tags"));
                    }
                    manager.setTags(tags);
                } catch (Exception ex) {
                    Log.e(TAG, "Median OneSignal Exception", ex);
                    PluginUtils.sendErrorCallback(activity, callback, ex.getMessage());
                }
                return true;
            }

            if ("/tags/delete".equals(url.getPath())) {
                if (params != null) {
                    String callback = params.optString("callback");
                    try {
                        JSONArray tags = params.optJSONArray("tags");
                        if (tags == null) {
                            try {
                                tags = new JSONArray(params.optString("tags"));
                            } catch (JSONException e) {
                                // ignore
                            }
                        }
                        manager.deleteTags(activity, tags, callback);
                    } catch (Exception ex) {
                        PluginUtils.sendErrorCallback(activity, callback, ex.getMessage());
                    }
                } else {
                    manager.deleteAllTags();
                }

                return true;
            }
            
            if ("/promptLocation".equals(url.getPath())) {
                manager.promptLocation();
                return true;
            }
            
            if ("/userPrivacyConsent/grant".equals(url.getPath())) {
                manager.provideUserConsent(true);
                AppConfig appConfig = AppConfig.getInstance(activity);
                if (appConfig.oneSignalAutoRegister) {
                    manager.promptForPushNotifications();
                }
                return true;
            }
            
            if ("/userPrivacyConsent/revoke".equals(url.getPath())) {
                manager.provideUserConsent(false);
                return true;
            }
            
            if ("/showTagsUI".equals(url.getPath())) {
                manager.startSubscriptionActivity(activity);
                return true;
            }
            
            if ("/iam/addTrigger".equals(url.getPath()) && params != null) {
                String key = params.optString("key");
                String value = params.optString("value");
                manager.addTrigger(key, value);
                return true;
            }
            
            if ("/iam/addTriggers".equals(url.getPath()) && params != null) {
                Object json = params.optString("map").isEmpty() ? params : params.optString("map");
                manager.addTriggers(json);
                return true;
            }
            
            if ("/iam/removeTriggerForKey".equals(url.getPath()) && params != null) {
                manager.removeTrigger(params.optString("key"));
                return true;
            }
            
            if ("/iam/getTriggerValueForKey".equals(url.getPath()) && params != null) {
                manager.getTriggerValueForKey(activity, params.optString("key"));
                return true;
            }
            
            if ("/iam/pauseInAppMessages".equals(url.getPath()) && params != null) {
                manager.pauseInAppMessages(params.optBoolean("pause"));
                return true;
            }
            
            if ("/iam/setInAppMessageClickHandler".equals(url.getPath()) && params != null) {
                manager.setInAppMessageClickHandler(activity, params.optString("handler"));
                return true;
            }
            
            if ("/externalUserId/set".equals(url.getPath()) && params != null) {
                String externalId = params.optString("externalId");
                String callback = params.optString("callback");
                manager.setExternalUserId(activity, externalId, callback);
                return true;
            }
            
            if ("/externalUserId/remove".equals(url.getPath())) {
                String callback = (params != null) ? params.optString("callback") : "";
                manager.removeExternalUserId(activity, callback);
                return true;
            }

            if ("/register".equals(url.getPath())) {
                String callback = "onesignal_register_callback";

                if (params != null) {
                    callback = params.optString("callback", callback);
                }

                manager.promptForPushNotifications(activity, callback);
                return true;
            }

            if ("/enableForegroundNotifications".equals(url.getPath()) && params != null) {
                AppConfig appConfig = AppConfig.getInstance(activity);
                appConfig.oneSignalShowForegroundNotifications = params.optBoolean("enabled", appConfig.oneSignalShowForegroundNotifications);
                manager.showForegroundNotifications(appConfig.oneSignalShowForegroundNotifications);
                return true;
            }
        }
        
        if ("run".equals(url.getHost())) {
            if ("/gonative_onesignal_info".equals(url.getPath())) {
                String callback = OneSignalManager.NATIVE_CALLBACK;
                if (params != null) {
                    callback = params.optString("callback", callback);
                }
                manager.sendOneSignalInfo(activity, callback);
                return true;
            }
        }
        
        return false;
    }
    
    @Override
    public Map<String, Object> getAnalyticsProviderInfo() {
        if (manager == null) return null;
        return manager.getInstallationInfo();
    }
    
    @Override
    public <T extends Activity & GoNativeActivity> void onPageFinish(T activity, boolean doNativeBridge) {
        if (manager == null || !doNativeBridge) return;
        manager.sendOneSignalInfo(activity, OneSignalManager.NATIVE_CALLBACK);

        manager.setPageReady(true);
    }
}
